@extends('layout')

@section('content')
<p>Este sitio es de prueba sobre laravel para Konecta</p>
<p><strong>Desarrollado por:</strong> Maycol David Sanchez Mora.</p>
<p><strong>Celular:</strong> 3217442558.</p>
@endsection
