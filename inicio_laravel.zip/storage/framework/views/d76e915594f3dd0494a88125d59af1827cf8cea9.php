

<?php $__env->startSection('content'); ?>
<p>Este sitio es de prueba sobre laravel para Konecta</p>
<p><strong>Desarrollado por:</strong> Maycol David Sanchez Mora.</p>
<p><strong>Celular:</strong> 3217442558.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inicio_laravel\resources\views/home.blade.php ENDPATH**/ ?>